$sql = "insert into registered values('$user', '$c_id', '$teacher' , '$slot', '$status')";
 
 CREATE TABLE registered (
   id int(11) NOT NULL,
   user varchar(100) NOT NULL,
   c_id varchar(50) NOT NULL,
   c_unit varchar(50) NOT NULL
   
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

 	
ALTER TABLE registered
  ADD PRIMARY KEY (`id`);


ALTER TABLE registered
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
    
 $c_id = $_POST['c_id'];
$c_name = $_POST['c_name'];
$c_unit = $_POST['c_unit'];
$c_faculty = $_POST['c_unit'];
$c_school = $_POST['school'];
$c_semester = $_POST['semester'];
$c_description = $_POST['description'];


CREATE TABLE courses2 (
   id int(11) NOT NULL,
   c_id varchar(50) NOT NULL,
   c_name varchar(50) NOT NULL,
   c_unit varchar(50) NOT NULL,
   c_faculty varchar(50) NOT NULL,
   c_school varchar(50) NOT NULL,
   c_semester varchar(50) NOT NULL,
   c_description varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



CREATE TABLE courses (
   id int(11) NOT NULL,
   c_id varchar(100) NOT NULL,
   c_name varchar(50) NOT NULL,
   school varchar(50) NOT NULL,
   sem varchar(50) NOT NULL,
   description varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



	
ALTER TABLE courses2
  ADD PRIMARY KEY (`id`);


ALTER TABLE courses2
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
    

CREATE TABLE faculty (
   id int(11) NOT NULL,
   teacher varchar(50) NOT NULL,
   c_id varchar(100) NOT NULL,
   slot varchar(50) NOT NULL,
   seats varchar(50) NOT NULL,
   waiting varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

  
 

ALTER TABLE faculty 
  ADD PRIMARY KEY (`id`);


ALTER TABLE faculty 
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
   
   
   CREATE TABLE faculty2 (
   id int(11) NOT NULL,
   code varchar(50) NOT NULL,
   name varchar(500) NOT NULL
   
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

  
 

ALTER TABLE faculty2 
  ADD PRIMARY KEY (`id`);


ALTER TABLE faculty2 
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
   

CREATE TABLE user2 (
   id int(11) NOT NULL,
   reg varchar(50) NOT NULL,
   fname varchar(50) NOT NULL,
   mname varchar(100) NOT NULL,
   lname varchar(100) NOT NULL,
   username varchar(100) NOT NULL,
   phone int(11) NOT NULL,
   email varchar(100) NOT NULL,
   school varchar(100) NOT NULL,
   branch  varchar(50) NOT NULL,
   type  varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



ALTER TABLE user2
  ADD PRIMARY KEY (`id`);


ALTER TABLE user2
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
  

CREATE TABLE loging (
   id int(11) NOT NULL,
   username varchar(100) NOT NULL,
   password varchar(100) NOT NULL,
    type  varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




ALTER TABLE loging
  ADD PRIMARY KEY (`id`);


ALTER TABLE loging
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
  	
	
	
CREATE TABLE  pre_req (
   id int(11) NOT NULL,
   c_id varchar(50) NOT NULL,
   prereq varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



ALTER TABLE `pre_req`
  ADD PRIMARY KEY (`id`);


ALTER TABLE pre_req
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
  




CREATE TABLE `users` (
   id int(11) NOT NULL,
   net_id varchar(50) NOT NULL,
   firstname varchar(50) NOT NULL,
   lastname varchar(50) NOT NULL,
   email varchar(50) NOT NULL,
   d_id int(11) NOT NULL,
   u_role  varchar(100) NOT NULL,
   phone int(11) NOT NULL,
   gender varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


$sql1="INSERT INTO user_login (net_id, password,salt_value) VALUES
 password varchar(100) NOT NULL
 
 
 
CREATE TABLE user_login (
   id int(11) NOT NULL,
    net_id varchar(50) NOT NULL,
   password varchar(100) NOT NULL,
   salt_value varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


ALTER TABLE user_login
  ADD PRIMARY KEY (`id`);

ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);


ALTER TABLE user_login
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
  
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;