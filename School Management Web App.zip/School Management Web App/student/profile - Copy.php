<!DOCTYPE html>

<html>
    
    <head><title>Register courses</title> 
        <link rel="stylesheet" href="style2.css"></head>
    
    <body>
    
<?php    
session_start();
?>

<?php
if(!isset($_SESSION['sess_username'])) {
  header("location: ../index.html");
  exit();
}
?>

<?php        

include('common.html');
        
$user = $_SESSION['sess_username'];        
$conn=new mysqli("localhost","root","","cu3");
        
$sql = "sELECT * FROM registered where id ='$user'";


	$result = mysqli_query($conn, $sql);
	
	if (mysqli_num_rows($result) > 0) {
        echo "
		
		
		<table><tr><th>Course Code</th><th>Course name</th><th>Course Unit</th><th>VIEW</th></tr>";
		while($row = mysqli_fetch_array($result,MYSQLI_ASSOC)){
            
			echo "<tr><td>" . $row["user"]. "</td><td>" . $row["c_id"] . "</td><td>" . $row["c_unit"] . "</td> <td>
            <form method='post' action=''>
            <input type='hidden' name='c_id' value='".$row["c_id"]."'>
			<input type='hidden' name='c_unit' value='".$row["c_unit"]."'>
            <input type='submit' name='submit' value='Register' class='submit'>
            </form><br></td></tr>";}
    echo "</table>";
    }
        else{echo "<br><br><h1 align='center'>You have no courses left to register</h1>";}
        
        mysqli_close($conn);
?>
    </body>
<?php
    
	
	
	
	
	
	if(isset($_POST['submit'])){
		
$c_unit = $_POST['c_unit'];
$c_id=$_POST['c_id'];
$user = $_SESSION['sess_username'];   

		
		

    $conn=new mysqli("localhost","root","","cu3");
	
	
//$sql = "insert into registered (user,c_id,c_unit) values('$user','$c_id', '$c_unit')";

$result = mysqli_query($conn, $sql);
        
        mysqli_close($conn);
		if($result){

echo "<script> alert('You have Registerd new courses')</script>";



}
		
		
    }
   
 ?>   
</html>