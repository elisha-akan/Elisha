<!DOCTYPE html>

<html>
    
    <head><title>Register courses</title> 
        <link rel="stylesheet" href="style2.css"></head>
    
    <body>
    
<?php    
session_start();
?>

<?php
if(!isset($_SESSION['sess_username'])) {
  header("location: ../index.html");
  exit();
}
?>

<?php        

include('common.html');
        
$user = $_SESSION['sess_username'];        
$conn=new mysqli("localhost","root","","cu3");
        
$sql = "sELECT * FROM registered where user ='$user'";


	$result = mysqli_query($conn, $sql);
	
	if (mysqli_num_rows($result) > 0) {
		

		
        //echo "
		echo "<h2><u>VIEW REGISTERED COURSES </u>:</h2>
		
		<table>
		<tr><th>Course Code</th><th>Course Unit</th><th>Remove</th></tr>";
		while($row = mysqli_fetch_array($result,MYSQLI_ASSOC)){
            
			echo "</td><td>" . $row["c_id"] . "</td><td>" . $row["c_unit"] . "</td> <td>
            <form method='post' action=''>
            <input type='hidden' name='c_id' value='".$row["c_id"]."'>
			<input type='hidden' name='c_unit' value='".$row["c_unit"]."'>
            <input type='submit' name='submit' value='Remove' class='submit'>
            </form><br></td></tr>";}
    echo "</table>";
	
	
    }
        else{echo "<br><br><h1 align='center'>You have not register any courses </h1>";}
        
        mysqli_close($conn);
		
		
?>
    </body>
		<?php
	
	if(isset($_POST['submit'])){
		
$c_unit = $_POST['c_unit'];
$c_id=$_POST['c_id'];
$user = $_SESSION['sess_username'];   

		
		

    $conn=new mysqli("localhost","root","","cu3");
	
	$sql="delete  FROM registered where c_id ='$c_id'";
//$sql = "insert into registered (user,c_id,c_unit) values('$user','$c_id', '$c_unit')";

$result = mysqli_query($conn, $sql);
        
        mysqli_close($conn);
		if($result){

echo "<script> alert('One Course Has Been Deleted') </script>";

echo "<script>window.open('student/view.php?,'_self')</script>";



}
		
		
    }
   
 ?>   
</html>