<!DOCTYPE html>

<html>
    
    
    
    <body>
    
<?php    
session_start();
?>

<?php
if(!isset($_SESSION['sess_username'])) {
  header("location: ../index.html");
 
}
?>



<?php

if(isset($_GET['delete'])){
$user = $_SESSION['sess_username']; 
$delete_id = $_GET['delete'];

$delete_cat = "delete  FROM registered where user ='$user'";

$run_delete = mysqli_query($con,$delete_cat);

if($run_delete){

echo "<script> alert('One Course Has Been Deleted') </script>";

echo "<script>window.open('view.php?,'_self')</script>";

}

}

?>

<?php } ?>


    </body>
  
</html>