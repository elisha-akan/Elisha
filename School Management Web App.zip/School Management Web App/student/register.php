<!DOCTYPE html>

<html>
    
    <head><title>Register courses</title> 
        <link rel="stylesheet" href="style2.css"></head>
    
    <body>
    
<?php    
session_start();
?>

<?php

if(!isset($_SESSION['sess_username'])) {
  header("location: ../index.html");
  exit();
}
?>

<?php        

include('common.html');
        
$user = $_SESSION['sess_username'];        
$conn=new mysqli("localhost","root","","cu3");
        
$sql = "sELECT * FROM courses2 where c_id not in (select c_id from registered where id ='$user')";


	$result = mysqli_query($conn, $sql);
	
	if (mysqli_num_rows($result) > 0) {
       // echo "
		 echo "<h2><u>REGISTER NEW COURES </u>:</h2>
		<div class='row'>
        <div class='col-lg-12 col-md-12 col-sm-12 col-xs-12'>
		
		<table><tr><th><H3>Course Code</h3></th><th><h3>Course name</h3></th><th><h3>Course Unit</h3></th><th><h3>Register</h3></th></tr>";
		while($row = mysqli_fetch_array($result,MYSQLI_ASSOC)){
            
			echo "<tr><td><h3>" . $row["c_id"]. "</h3></td><td><h3>" . $row["c_name"] . "</h3></td><td><h3>" . $row["c_unit"] . "</h3></td> <td>
            <form method='post' action=''>
            <input type='hidden' name='c_id' value='".$row["c_id"]."'>
			<input type='hidden' name='c_unit' value='".$row["c_unit"]."'>
            <input type='submit' name='submit' value='Register' class='submit'>
            </form><br></td></tr>";}
    echo "</td></td></table>";
    }
        else{echo "<br><br><h1 align='center'>You have no courses left to register</h1>";}
        
        mysqli_close($conn);
?>
    </body>
<?php
    
	
	
	
	
	
	if(isset($_POST['submit'])){
		
$c_unit = $_POST['c_unit'];
$c_id=$_POST['c_id'];
$user = $_SESSION['sess_username'];   

		
		

    $conn=new mysqli("localhost","root","","cu3");
	
	
$sql = "insert into registered (user,c_id,c_unit) values('$user','$c_id', '$c_unit')";

$result = mysqli_query($conn, $sql);
        
        mysqli_close($conn);
		if($result){

echo "<script> alert('You have Registerd new courses')</script>";



}
		
		
    }
   
 ?>   
</html>