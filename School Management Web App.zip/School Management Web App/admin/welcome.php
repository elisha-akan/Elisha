<!DOCTYPE html>

<html>
    
    <head><title>Welcome</title> 
    </head>
    <body>

<?php        
include('common.html');
        
        echo "<br><h1 align='center'>WELCOME ADMIN</h1><br>" ;
        echo "<br><br><h3 align='center'>This is Admin login choose from the menu of options what you want to do</h3>";
        
?>
    </body>
</html>