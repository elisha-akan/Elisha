<!DOCTYPE html>
<html>
    <head><title>Add course</title></head>
<body>
<?php
    include('common.html');
 
    ?>
    
    <div class="container">
	<div class="row">
	<div class="col-75"> 
      </div>
        <div>
		<H2>Add New Course </H2>
		</div>
		</div>
  <form action="" method="post">
   
  
    <div class="row">
	
	
	<div class="col-25"> 
      </div>
	  
      <div class="col-25">
       
      </div>
      <div class="col-75">
	   <label>Course Code</label>
        <input type="text" name="c_id" placeholder="course code..." required>
      </div>
    </div>
      
    <div class="row">
	
	<div class="col-25"> 
      </div>

      <div class="col-25">
        
      </div>
      <div class="col-75">
	  <label>Course Name</label>
        <input type="text" name="c_name" placeholder="course name.." required>
      </div>
    </div>
	
	
	<div class="row">
	
	<div class="col-25"> 
      </div>
	  
      <div class="col-25">
        
      </div>
      <div class="col-75">
	  <label>Unit Point</label>
        <input type="text" name="c_unit" placeholder="course unit.." required>
      </div>
    </div>
      
	  
	    <div class='row'>
		
		<div class="col-25"> 
      </div>
        <div class='col-25'>
        
		</div><div class='col-75'>
		<label>Faculty</label>
                    <select name='course' required>
				    <option >---select an option---</option>
		    <?php
			$conn=new mysqli("localhost","root","","cu3");
$get_cat = "select * from faculty2 ";

$run_cat = mysqli_query($conn,$get_cat);

while ($row_cat=mysqli_fetch_array($run_cat)) {

$c_faculty = $row_cat['id'];

$cat_id = $row_cat['name'];

echo "<option value='$c_faculty'>$cat_id</option>";

}
			
            ?>
            </select></div></div> 
	  
	  
    <div class="row">
	
	<div class="col-25"> 
      </div>
    <div class="col-25">
       
		</div> 
        <div class="col-75">
		 <label>School</label>
					<select name="school" required>
                    <option disable selected value>---select an option---</option>
					<option value="CSE">Computer Science</option>
					<option value="MEC">Mechanical</option>
					<option value="ACC">Accounting</option>
					<option value="ARTS">Arts</option>
					<option value="BIO">Biology</option>
					<option value="BUS">Business Analytics</option>
					<option value="IT">Information Technology</option>
					</select></div></div>
      
    <div class="row">
	<div class="col-25"> 
      </div>
      <div class="col-25">
          
		  </div>
		  <div class="col-75">
		  <label>Semester</label>
                    <select name="semester" required>
				    <option disable selected value>---select an option---</option>
					<option value="ist semester">First semester</option>
					<option value="snd semester">Second semester</option>
					<option value="winter">winter(17-18)</option>
					<option value="fall">fall(17-18)</option>
					</select></div></div>
      
    
      
    <div class="row">
	<div class="col-25"> 
      </div>
	
      <div class="col-25">
	  
      
      </div>
      <div class="col-75">
	  <label>Course description:</label>
        <textarea name="c_description" placeholder="Write about course..." style="height:150px" required></textarea>
      </div>
    </div>
	
	<div class="row">
	<div class="col-1o"> 
      </div>
	
      <div class="col-75"> 
      </div>
	  
      <div class="col-25">
        
		
	  <input type="submit"  name="submit" value="submit" class="submit2">
    
      </div>
    </div>
      <br>
      
   
      
  </form>
</div>

</body>
<?php
    
	if(isset($_POST['submit'])){
$c_id = $_POST['c_id'];
$c_name = $_POST['c_name'];
$c_unit = $_POST['c_unit'];
$c_faculty = $_POST['course'];
$c_school = $_POST['school'];
$c_semester = $_POST['semester'];
$c_description = $_POST['c_description'];

    $conn=new mysqli("localhost","root","","cu3");
	
	

$sql = "insert into courses2 (c_id,c_name,c_unit,c_faculty,c_school,c_semester,c_description) values('$c_id','$c_name','$c_unit','$c_faculty','$c_school','$c_semester','$c_description')";
$result = mysqli_query($conn, $sql);
        
       // echo "<h1 align='center'>ENTER NEXT COURSE TEACHER DETAILS</h1>"  ;  
        mysqli_close($conn);
		if($result){

echo "<script> alert('New courses Has Been Inserted')</script>";



}
		
		
    }
   
 ?>   
</html>