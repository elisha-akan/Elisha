<!DOCTYPE html>
<html>
    <head><title>Add Faculty</title></head>
<body>
<?php
    include('common.html');
	
    ?>
    
    <div class="container">
 
     <form action="" method='post'> 
         <div class="row">
	<div class="col-75"> 
      </div>
        <div>
		<H2>Add New Faculty </H2>
		</div>
		</div>
      
    <div class="row">
	
	
	
      <div class="row">
	  <div class="col-25"> 
      </div>
	  
      <div class="col-25">
        <label>Faculty Code</label>
      </div>
      <div class="col-75">
        <input type="text" name="code" placeholder="faculty code.." required>
      </div>
    </div>
	
	<div class="row">
	
	<div class="col-25"> 
      </div>
      <div class="col-25">
        <label>Faculty Name</label>
      </div>
      <div class="col-75">
        <input type="text" name="name" placeholder="faculty name.." required>
      </div>
    </div>
	
     
      
    <div class="row">
	<div class="col-1o"> 
      </div>
	
      <div class="col-75"> 
      </div>
	  
      <div class="col-25">
        
		
	  <input type="submit"  name="submit" value="submit" class="submit2">
    
      </div>
    </div>
  </form>
</div>

</body>

<?php
    
	if(isset($_POST['submit'])){
$code = $_POST['code'];
$name = $_POST['name'];

    $conn=new mysqli("localhost","root","","cu3");

$sql = "insert into faculty2(code,name) values('$code','$name')";
$result = mysqli_query($conn, $sql);
        
       // echo "<h1 align='center'>ENTER NEXT COURSE TEACHER DETAILS</h1>"  ;  
        mysqli_close($conn);
		if($result){

echo "<script> alert('New Faculty Has Been Inserted')</script>";



}
		
		
    }
   
 ?>   
</html>