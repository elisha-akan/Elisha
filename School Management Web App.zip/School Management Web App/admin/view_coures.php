<!DOCTYPE html>
<html>
    <head><title>Course List</title></head>
<body>
<?php
    include('common.html');
	
    ?>
    
    <div class="container">
 
     <form action="" method='post'> 
         <div class="row">
	<div class="col-75"> 
      </div>
        <div>
		<H2>Course List </H2>
		</div>
		</div>
		
		<div class="row">
	<div class="col-25"> 
      
		<th><H2>Course Code</h2></th>
		</div>
		
		<div class="col-25"> 
      
		<th><H2>Course Name</h3></th>
		</div>
		
		<div class="col-25"> 
      
		<th><H2>Unit Point</h3></th>
		</div>
		
		
		<div class="col-25"> 
      
		<th><H2>Depertment</h3></th>
		</div>
		
				<div class="col-25"> 
      
		<th><H2>Semester</h3></th>
		</div>
		
		<div class="col-25"> 
      
		<th><H2>Description</h3></th>
		</div>
		
		
		</div>
      
	  
    <div class="row">
	
	
	
      <?php
	  
	  $con=new mysqli("localhost","root","","cu3");
                        $get_slide = "select * from courses2 ";
                        $run_slide = mysqli_query($con, $get_slide); 
                        while($row_slide=mysqli_fetch_array($run_slide)){
                            $slide_id = $row_slide['c_id'];                         
                            $slide_name = $row_slide['c_name'];
                            $slide_unit = $row_slide['c_unit'];
							$slide_school = $row_slide['c_school'];
							$slide_c_semister = $row_slide['c_semester'];
							$slide_description = $row_slide['c_description'];
                            
                            echo"
                       

<div class='row'>
	
	
      
      <div class='col-25'>
	  
        <h4>$slide_id</h4>
      </div>
	  <div class='col-25'>
        <h4>$slide_name</h4>
      </div>
	  
	  <div class='col-25'>
        <h4>$slide_unit</h4>
      </div>
	  
	  <div class='col-25'>
        <h4>$slide_school</h4>
      </div>
	  
	  <div class='col-25'>
        <h4>$slide_c_semister</h4>
      </div>
	  
	  <div class='col-25'>
        <h4>$slide_description</h4>
      </div>
	  
    </div>
										   
					
					
					
					
					
                            ";

                        }
                        ?>
	
	
     
      
    <div class="row">
	<div class="col-1o"> 
      </div>
	
      <div class="col-75"> 
      </div>
	  
      <div class="col-25">
        
		
	 
    
      </div>
    </div>
  </form>
</div>

</body>

<?php
    
	if(isset($_POST['submit'])){
$code = $_POST['code'];
$name = $_POST['name'];

    $conn=new mysqli("localhost","root","","cu3");

$sql = "insert into faculty2(code,name) values('$code','$name')";
$result = mysqli_query($conn, $sql);
        
       // echo "<h1 align='center'>ENTER NEXT COURSE TEACHER DETAILS</h1>"  ;  
        mysqli_close($conn);
		if($result){

echo "<script> alert('New Faculty Has Been Inserted')</script>";



}
		
		
    }
   
 ?>   
</html>